# Contexto do projeto — Painel do Torneio (Lançador de Spinner)

Este arquivo existe para dar contexto rápido ao Claude Code ao abrir este
repositório, sem precisar reexplicar tudo do zero.

## Quem é o usuário

Adilson, professor de Matemática/Robótica (SEDUC-SP e SESI-SP), na EE Hugo de
Aguiar. Este projeto específico é para o componente **Programação e
Robótica do SESI**, não Matemática da rede estadual.

## O evento

**Torneio Infantil SESI** (outubro), tema "Especialidades". A prova tratada
aqui é do **2º Ano do Ensino Fundamental**, chamada **"Prova da Propulsão —
Lançador de Spinner"**, usando o kit **LEGO Education Early Simple Machines
9656**.

## Estrutura da competição (regras já fechadas com o usuário)

- 4 turmas: **2ºA, 2ºB, 2ºC, 2ºD**, 32 alunos cada.
- Cada turma se divide em **4 grupos de 8 alunos**.
- **4 rodadas**: na Rodada N, o Grupo N de cada uma das 4 turmas compete
  simultaneamente (Grupo 1 do 2ºA vs Grupo 1 do 2ºB vs Grupo 1 do 2ºC vs
  Grupo 1 do 2ºD, e assim por diante).
- Em cada rodada, o grupo (8 integrantes) monta o lançador **em equipe** e
  depois lança o spinner.
- Dois critérios cronometrados por rodada/equipe:
  - **Tempo de montagem** (menor tempo é melhor)
  - **Tempo de giro** do spinner na pista (maior tempo é melhor)
- Pontuação por colocação, **separadamente por critério**: 1º=4, 2º=3, 3º=2,
  4º=1 ponto. A pontuação da equipe na rodada = pontos de montagem + pontos
  de giro (a mesma equipe pode ter uma colocação em cada critério).
- Pontuação final da turma = soma das 4 rodadas.
- Desempate: mais 1ºs lugares em tempo de giro.
- Regras completas em `docs/regulamento.md`.

Todo esse regulamento já foi validado com o usuário em conversa anterior —
**não renegociar as regras sem ele pedir explicitamente.**

## O app atual (`app/Painel_Torneio_Spinner.jsx`)

- É um **artifact React do Claude.ai** (não um projeto Vite/CRA convencional
  ainda). Usa `window.storage` (API de armazenamento de artifacts, com
  `shared: true`) para sincronizar dados entre todos os dispositivos que
  abrem o mesmo link do artifact — sem backend próprio.
- Dois modos de tela, alternados por um toggle no topo: **Monitor** (input de
  tempos por mesa) e **Telão/Ranking** (placar ao vivo, somente leitura).
- Modelo de dados: uma chave por rodada+equipe, formato `r{round}_{teamId}`
  (ex: `r1_2A`), valor JSON `{ montagem: number|null, giro: number|null }`.
  Detalhes em `docs/modelo-de-dados.md`.
- **Limitação conhecida:** funciona perfeitamente como artifact dentro do
  Claude.ai (o usuário já está usando dessa forma). Se for publicado como
  site estático (GitHub Pages, Vercel, etc.), a sincronização em tempo real
  **não funciona** porque `window.storage` não existe fora do ambiente de
  artifacts — precisa ser trocado por um backend real (ver próxima seção).

## Se o pedido for "hospedar fora do Claude.ai" / "tornar standalone"

Isso exige adicionar um backend com sincronização em tempo real. Opções
razoáveis, do mais simples ao mais robusto:

1. **Firebase Realtime Database ou Firestore** (mais rápido de configurar,
   tem SDK client-side, suporta listeners em tempo real — troca direta das
   funções `safeGet`/`safeSet`/`safeDelete` do app atual).
2. **Supabase Realtime** (Postgres + realtime subscriptions, similar em
   esforço ao Firebase).
3. **Servidor próprio com WebSocket** (Node + `ws` ou Socket.IO) — mais
   trabalho, mais controle.

Ao migrar, preservar:
- O modelo de dados (`docs/modelo-de-dados.md`) e a lógica de cálculo de
  pontos (`rankPoints` no código atual) — isso já foi validado com o usuário.
- Os dois modos de tela (Monitor / Telão).
- Adicionar, se possível, autenticação simples por mesa (o usuário mencionou
  isso como melhoria desejada — hoje qualquer pessoa com o link pode editar
  qualquer equipe).

## Convenções de identidade visual (herdadas de outros materiais do projeto)

- Cores: azul `#004B8D` (primária), laranja `#F5821F` (destaque), e cores por
  equipe: 2ºA vermelho `#D92B2B`, 2ºB azul `#004B8D`, 2ºC verde `#2E9E4F`,
  2ºD amarelo `#F0B800`.
- Fontes seguras para qualquer material gerado (docx/pptx/pdf fora deste
  app): Calibri/Arial.
- **Não usar personagens Pokémon ou qualquer IP de terceiros** em nenhum
  material visual deste projeto — o usuário pediu isso originalmente
  (inspirado num cartaz promocional do torneio) e foi recusado por direitos
  autorais. Caso o tema "evolução por equipe" volte a aparecer, usar apenas
  ilustrações/mascotes originais.

## O que ainda não foi feito

- Botão de reset/"zerar torneio" no app.
- Exportação de resultado final (CSV/PDF).
- Autenticação por mesa.
- Qualquer versão standalone com backend real.
