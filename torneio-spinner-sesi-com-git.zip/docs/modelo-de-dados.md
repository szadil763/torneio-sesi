# Modelo de dados — Painel do Torneio

## Chaves de armazenamento

Cada combinação de **rodada + equipe** é uma chave independente, no formato:

```
r{round}_{teamId}
```

- `round`: `1`, `2`, `3` ou `4`
- `teamId`: `2A`, `2B`, `2C`, `2D`

Exemplos: `r1_2A`, `r3_2D`.

**Por que uma chave por rodada+equipe (e não uma chave única com tudo)?**
Como as 4 mesas de uma rodada podem salvar resultados quase ao mesmo tempo, e
o armazenamento do artifact usa "last write wins" (a última escrita
sobrescreve o valor inteiro daquela chave), uma chave única para todo o
torneio correria o risco de uma mesa sobrescrever o resultado que outra mesa
acabou de salvar. Com uma chave por rodada+equipe, cada mesa escreve na sua
própria chave, sem colidir com as outras.

## Valor de cada chave

JSON com dois campos, ambos em segundos (`number`) ou `null` se ainda não
cronometrado:

```json
{
  "montagem": 34.2,
  "giro": 12.5
}
```

## Cálculo de pontos (função `rankPoints`)

Implementado no app (`app/Painel_Torneio_Spinner.jsx`). Para um critério
(montagem ou giro) de uma rodada:

1. Reúne os valores das 4 equipes para aquele critério.
2. Ordena — ascendente para montagem (menor tempo = melhor), descendente
   para giro (maior tempo = melhor).
3. Atribui pontos `[4, 3, 2, 1]` na ordem.
4. Em caso de empate exato de valor, a equipe empatada recebe os mesmos
   pontos da posição mais alta empatada.

Uma rodada só é considerada "completa" (e portanto pontuada) quando as 4
equipes têm **ambos** os tempos (`montagem` e `giro`) preenchidos. Antes
disso, a rodada aparece como "aguardando resultados" no Telão.

## Pontuação total por equipe

Soma, para todas as rodadas completas, de:

```
pontos_montagem_da_rodada + pontos_giro_da_rodada
```

## Migrando para um backend real (fora do Claude.ai)

Se o app for movido para um backend com banco de dados real (Firebase,
Supabase, etc.), o modelo acima pode ser preservado quase 1:1:

- Uma coleção/tabela `resultados`, com `id` = `r{round}_{teamId}` (ou colunas
  separadas `round` e `team_id`), e colunas `montagem` (float, nullable) e
  `giro` (float, nullable).
- Substituir as funções `safeGet` / `safeSet` / `safeDelete` do app atual
  pelas chamadas equivalentes do novo backend (mantendo a mesma assinatura,
  para não precisar reescrever o resto do componente).
- Se o backend suportar subscriptions em tempo real (Firestore
  `onSnapshot`, Supabase Realtime, etc.), o polling de 4 segundos do Telão
  pode ser substituído por um listener — atualização instantânea em vez de
  a cada poucos segundos.
