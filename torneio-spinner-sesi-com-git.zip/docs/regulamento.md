# Regulamento — Prova da Propulsão (Lançador de Spinner)

**SESI — Torneio Infantil** · 2º Ano · Turmas A, B, C e D

## 1. Sobre a prova

Cada turma do 2º ano (32 alunos) é dividida em **4 grupos de 8
integrantes**. Cada grupo monta, em equipe, um lançador de spinner com peças
LEGO Education (kit **9656 — Early Simple Machines**) e disputa contra os
grupos correspondentes das outras turmas.

Equipes: **2º A**, **2º B**, **2º C**, **2º D**.

## 2. Formato do torneio

São **4 rodadas** no total. Em cada rodada, o grupo de número correspondente
de cada turma compete simultaneamente:

- **Rodada 1:** Grupo 1 do 2ºA 🆚 Grupo 1 do 2ºB 🆚 Grupo 1 do 2ºC 🆚 Grupo 1 do 2ºD
- **Rodada 2:** Grupo 2 do 2ºA 🆚 Grupo 2 do 2ºB 🆚 Grupo 2 do 2ºC 🆚 Grupo 2 do 2ºD
- **Rodada 3:** Grupo 3 do 2ºA 🆚 Grupo 3 do 2ºB 🆚 Grupo 3 do 2ºC 🆚 Grupo 3 do 2ºD
- **Rodada 4:** Grupo 4 do 2ºA 🆚 Grupo 4 do 2ºB 🆚 Grupo 4 do 2ºC 🆚 Grupo 4 do 2ºD

## 3. Critérios avaliados em cada rodada

- **⏱️ Tempo de montagem** — cronometrado do início ao fim da montagem
  completa do lançador pelo grupo (8 integrantes). Menor tempo é melhor.
- **🌀 Tempo de giro** — cronometrado a partir do lançamento do spinner até
  ele parar de girar na pista demarcada. Maior tempo é melhor.

## 4. Sistema de pontuação

Em cada rodada, os 4 grupos recebem pontos conforme a colocação —
**separadamente em cada critério**:

| Colocação | Pontos |
|---|---|
| 🥇 1º lugar | 4 pontos |
| 🥈 2º lugar | 3 pontos |
| 🥉 3º lugar | 2 pontos |
| 4º lugar | 1 ponto |

A pontuação do grupo na rodada é a **soma dos pontos de montagem + pontos de
giro** (máximo 8, mínimo 2 pontos por rodada).

Em caso de **empate exato** de tempo entre duas ou mais equipes num
critério, todas recebem os mesmos pontos (os da melhor colocação empatada).

## 5. Pontuação final e critério de desempate

- Somam-se os pontos dos 4 grupos de cada turma ao longo das 4 rodadas.
- A turma (2ºA, 2ºB, 2ºC ou 2ºD) com o **maior total de pontos** é a campeã
  da Prova da Propulsão.
- **Em caso de empate:** vence a turma com o maior número de **1º lugares em
  tempo de giro** ao longo do torneio.

## 6. Regras gerais

- Todos os 8 integrantes do grupo devem participar ativamente da montagem.
- O lançamento só é cronometrado após a confirmação de montagem completa por
  um responsável.
- Se o spinner sair da área demarcada antes de parar, o tempo é registrado
  até o momento da saída.
- Cooperação, respeito e espírito esportivo valem mais do que vencer — todas
  as equipes são reconhecidas pela dedicação e pelo esforço.
