# Painel do Torneio — Prova da Propulsão (Lançador de Spinner)

App de cronometragem e ranking ao vivo para a prova "Lançador de Spinner" do
Torneio Infantil SESI, 2º Ano (Turmas A, B, C e D).

## O que o app faz

- **Modo Monitor** (uma mesa/dispositivo por equipe): cronometra o tempo de
  **montagem** do lançador e o tempo de **giro** do spinner, e salva o
  resultado da rodada.
- **Modo Telão/Ranking**: mostra o placar ao vivo — pontuação calculada
  automaticamente por colocação (1º=4, 2º=3, 3º=2, 4º=1 pontos, somando
  montagem + giro) e o ranking geral das 4 equipes, atualizando sozinho.
- Todos os dispositivos com acesso ao link veem os **mesmos dados em tempo
  real** — um monitor salva o tempo numa mesa, e o telão (ou qualquer outro
  dispositivo) reflete isso em poucos segundos.

## Como está implementado hoje

O arquivo em [`app/Painel_Torneio_Spinner.jsx`](app/Painel_Torneio_Spinner.jsx)
foi construído como um **artifact React do Claude.ai**, usando a API de
armazenamento embutida do artifact (`window.storage`, com `shared: true`)
para sincronizar os dados entre todos que abrem o mesmo link do artifact.

**Importante:** essa API (`window.storage`) só existe dentro do ambiente de
artifacts do Claude.ai/Claude apps. Se este arquivo for publicado como site
estático (ex: GitHub Pages), o app abre normalmente, mas `window.storage` não
vai existir — ou seja, **os dados não vão sincronizar entre dispositivos**
fora do Claude.ai.

### Duas formas de usar este repositório

1. **Uso imediato, sem infraestrutura própria:** continue rodando o app como
   artifact dentro do Claude.ai — compartilhe o link do artifact com os
   monitores de cada mesa e com quem for operar o telão. Funciona hoje, sem
   nenhuma configuração extra.
2. **Versão standalone (hospedada no GitHub Pages, domínio próprio, etc.):**
   requer trocar a camada de armazenamento por um backend real com
   sincronização em tempo real (ex: Firebase Firestore/Realtime Database,
   Supabase Realtime, ou um pequeno servidor WebSocket). O modelo de dados já
   está documentado em [`docs/modelo-de-dados.md`](docs/modelo-de-dados.md)
   para facilitar essa migração — é basicamente trocar as funções
   `safeGet` / `safeSet` / `safeDelete` por chamadas ao novo backend, mantendo
   o resto do app igual.

## Regulamento da prova

Ver [`docs/regulamento.md`](docs/regulamento.md) — regras completas de
formato, critérios e pontuação que o app implementa.

## Estrutura do repositório

```
torneio-spinner-sesi/
├── README.md                     — este arquivo
├── CLAUDE.md                     — contexto do projeto para o Claude Code
├── app/
│   └── Painel_Torneio_Spinner.jsx — código-fonte do app (React)
└── docs/
    ├── regulamento.md             — regras oficiais da prova
    └── modelo-de-dados.md         — chaves de armazenamento e cálculo de pontos
```

## Próximos passos possíveis

- Migrar o armazenamento para um backend real (ver seção acima) para permitir
  hospedagem fora do Claude.ai.
- Adicionar autenticação simples por mesa (evitar que qualquer pessoa com o
  link edite os tempos de qualquer equipe).
- Botão de "zerar torneio" para reutilizar o app em edições futuras.
- Exportar o resultado final (CSV/PDF) ao fim do torneio.
